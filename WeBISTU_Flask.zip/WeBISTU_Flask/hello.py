import login
import flask
from flask import Flask
from flask import request
import json


app = Flask(__name__)


@app.route("/",methods=['POST'])

def hello():
    Account = request.form['xh']
    Password = request.form['password']
    print(Account,Password)
    data = {}
    try:
        data = login.User_login(Account,Password)
        data = json.dumps(data, ensure_ascii=False)
        return data
    except:
        print("登陆失败")
        return "ERROR"

    # print(data)
    # return data
# @app.route("/kb",methods=['post'])
# def kb():
#     return 0
if __name__ == "__main__":
    app.run(debug=True, ssl_context=(r'C:\Users\Administrator\Desktop\server.pem', r'C:\Users\Administrator\Desktop\server.key'), host='0.0.0.0', port=8080)