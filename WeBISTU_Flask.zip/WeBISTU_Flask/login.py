import json
import requests
import ssl
import Img
from bs4 import BeautifulSoup
import bs4
requests.packages.urllib3.disable_warnings()
ssl._create_default_https_context = ssl._create_unverified_context

login_head = '''Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
Accept-Encoding:gzip, deflate
Accept-Language:zh-CN,zh;q=0.9
Cache-Control:max-age=0
Connection:keep-alive
Content-Length:201
Content-Type:application/x-www-form-urlencoded
Host:jwgl.bistu.edu.cn
Origin:http://jwgl.bistu.edu.cn
Referer:http://jwgl.bistu.edu.cn/(0c4kqtjwryxbzb55kz4re3qy)/default2.aspx
Upgrade-Insecure-Requests:1
User-Agent:Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.62 Safari/537.36'''

mark_head = '''Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
Accept-Encoding:gzip, deflate
Accept-Language:zh-CN,zh;q=0.9
Connection:keep-alive
Cookie:__utma=53807035.148301984.1544349859.1548770612.1548811691.6; __utmz=53807035.1548811691.6.5.utmcsr=baidu|utmccn=(organic)|utmcmd=organic; Hm_lvt_2001062cf1eba9e5e337e8464dd128dc=1546349865,1546350190,1548770612,1548811691; _trs_uv=jpgq16ci_397_e3yh
Host:jwgl.bistu.edu.cn
Referer:http://jwgl.bistu.edu.cn/(0c4kqtjwryxbzb55kz4re3qy)/xs_main.aspx?xh=2017011399
Upgrade-Insecure-Requests:1
User-Agent:Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.62 Safari/537.36'''


def tableToList(document):
    document = str(document)
    soup = BeautifulSoup(document, 'lxml')
    # 得到table中的每一项，存到item中
    lines = soup.table.find_all('tr')
    items = []
    for line in lines:
        lineList = []
        for item in line.find_all('td'):
            lineList.append(item.text)
        items.append(lineList)
    return items


def class_tableToList(document):
    document = str(document)
    soup = BeautifulSoup(document, 'lxml')
    # 得到table中的每一项，存到item中
    lines = soup.table.find_all('tr')
    items = []
    for line in lines:
        lineList = []
        for item in line.find_all('td'):
            item = item.text.replace('\xa0', '')
            lineList.append(item.split())
        items.append(lineList)
    return items


def getHeaders(raw_head):
    headers = {}
    for raw in raw_head.split('\n'):
        headerkey, headerValue = raw.split(':', 1)
        headers[headerkey] = headerValue
    return headers


header1 = getHeaders(login_head)
header2 = getHeaders(mark_head)


def text_wrap(start_str, end_str, html):
    start = html.find(start_str)
    if start >= 0:
        start += len(start_str)
        end = html.find(end_str, start)
        if end >= 0:
            return html[start:end]


def User_login(Account, password):
    # 构造session
    s = requests.session()

    # 请求URL
    url = 'http://jwgl.bistu.edu.cn/(0c4kqtjwryxbzb55kz4re3qy)/'
    # /zfca/login?service=http%3A%2F%2Fjxgl.bistu.edu.cn%2Fportal.do'
    # 登录页面
    # 获取登录headers
    headers = header1
    # 构造post表单
    # print(headers)
    formtable = {
        '__VIEWSTATE': '',
        'txtUserName': '',
        'Textbox1': '',
        'TextBox2': '',
        'txtSecretCode': '',
        'RadioButtonList1': '%D1%A7%C9%FA',
        'Button1': '',
        'lbLanguage': '',
        'hidPdrs': '',
        'hidsc': ''
    }

    formtable['txtUserName'] = Account
    formtable['TextBox2'] = password
    user = []
    user.append(Account)
    user.append(password)

    pic = requests.get(url + 'CheckCode.aspx').content
    with open('ver_pic.png', 'wb') as f:
        f.write(pic)

    b = Img.ImgToText()
    # string=str(b,'utf-8')
    # print(b)
    formtable['txtSecretCode'] = b

    login_page = s.get(url + 'default2.aspx')
    soup = BeautifulSoup(login_page.text, 'lxml')
    __VIEWSTATE = soup.find('input', attrs={'name': '__VIEWSTATE'}).get('value')
    formtable['__VIEWSTATE'] = __VIEWSTATE

    context = ssl._create_unverified_context()
    Pageurl = url + 'default2.aspx'
    res = s.post(Pageurl, formtable, headers=headers,verify=False)
    # print(res)

    # 主页面
    # 获取成绩查询链接

    page = s.get(url + '/xs_main.aspx?xh=' + Account,verify=False)
    soup2 = BeautifulSoup(page.text, 'lxml')
    markurl = soup2.find('a', attrs={'onclick': "GetMc('个人成绩查询');"}).get('href')
    kburl = soup2.find('a', attrs={'onclick': "GetMc('学生个人课表');"}).get('href')
    examurl = soup2.find('a', attrs={'onclick': "GetMc('学生考试查询');"}).get('href')
    # 成绩查询界面

    # 获取成绩查询Headers
    headers = header2

    # Post表单
    formtable = {
        '__VIEWSTATE': '',
        'ddlXN': '',
        'ddlXQ': '',
        'Button5': '%B0%B4%D1%A7%C4%EA%B2%E9%D1%AF'
    }

    # 获取__VIEWSTATE
    markpage = s.get(url + markurl, headers=headers)
    soup = BeautifulSoup(markpage.text, 'lxml')
    __VIEWSTATE = soup.find('input', attrs={'name': '__VIEWSTATE'}).get('value')
    formtable['__VIEWSTATE'] = __VIEWSTATE


    # 提交表单，获取成绩查询界面
    markpage = s.post(url + markurl, formtable, headers=headers,verify=False)

    soup3 = BeautifulSoup(markpage.text, 'lxml')
    #获取姓名，专业
    name = str(soup3.find_all(id="Label5")[0].text)
    name = name[3:]
    major = str(soup3.find_all(id="Label7")[0].text)
    # 获取绩点、成绩信息
    JiDian = str(soup3.find_all(id="pjxfjd"))
    soup = BeautifulSoup(JiDian, 'lxml')
    GPA = soup.find_all('b')[0]
    GPA = GPA.string
    marktable = str(soup3.find_all(id="Datagrid1")[0])
    marklist = tableToList(marktable)

    #获取考试信息
    exampage = s.post(url + examurl, headers=headers)
    soupExam = BeautifulSoup(exampage.text, 'lxml')

    Examtable = str(soupExam.find_all(id="DataGrid1")[0])
    Examlist = tableToList(Examtable)

    del Examlist[0]
    print(Examlist)



    # 获取课表信息

    kbpage = s.get(url + kburl, headers=header2)
    kbpage = kbpage.text.replace('<br/>', ' ').replace('<br>', ' ')
    soup = BeautifulSoup(kbpage, 'lxml')
    Class = str(soup.find_all(id="Table1")[0])
    Class_list = class_tableToList(Class)
    # 处理课表信息
    list = [0, 0, 1, 2, 2, 3, 4, 5, 5, 5]
    i = 0
    for j in list:
        del Class_list[list[i]]
        i = i + 1
    del Class_list[0][0]
    del Class_list[0][0]
    del Class_list[1][0]
    del Class_list[2][0]
    del Class_list[2][0]
    del Class_list[3][0]
    del Class_list[4][0]
    del Class_list[4][0]

    # 处理各科成绩和绩点
    grade = []
    for line in marklist:
        a = []
        a.append(line[3])
        a.append(line[7][3:])
        a.append(line[12])
        a.append(line[6])
        grade.append(a)
    del grade[0]
    # for key in grade:
    #     print(key + ':' + grade[key][0]+' ' + grade[key][1])
    # print(grade)
    State_Code = str(res)
    # print(State_Code[11:-2])
    State_Code = State_Code[11:-2]

    #print(Class_list)

    # for cls in Class_list[2]:
    #     if(cls[2][5]=='5'):
    #         cls.append('1')
    # 格式化课表信息
    for Class in Class_list:
        for lesson in Class:
            cls1 = {}
            if (len(lesson) == 5):
                cls1['name'] = lesson[0]
                cls1['teacher'] = lesson[3]
                cls1['room'] = lesson[4]
                cls1['begin'] = text_wrap('{', '-', lesson[2])[1:]
                cls1['end'] = text_wrap('-', '周', lesson[2])
                cls1['isDan'] = 0
                if ('单' in lesson[2]):
                    cls1['isDan'] = 1
                elif ('双' in lesson[2]):
                    cls1['isDan'] = 2
                cls1['length'] = 2
                if (lesson[2][7] == '5'):
                    cls1['length'] = 3

                lesson.clear()
                lesson.append(cls1)
            if (len(lesson) == 10):
                cls1 = {}
                cls1['name'] = lesson[0]
                cls1['teacher'] = lesson[3]
                cls1['room'] = lesson[4]
                cls1['begin'] = text_wrap('{', '-', lesson[2])[1:]
                cls1['end'] = text_wrap('-', '周', lesson[2])
                cls1['isDan'] = 0
                if ('单' in lesson[2]):
                    cls1['isDan'] = 1
                elif ('双' in lesson[2]):
                    cls1['isDan'] = 2
                cls1['length'] = 2
                if (lesson[2][7] == '5'):
                    cls1['length'] = 3
                lesson.append(cls1)

                cls1 = {}
                cls1['name'] = lesson[5]
                cls1['teacher'] = lesson[8]
                cls1['room'] = lesson[9]
                cls1['begin'] = text_wrap('{', '-', lesson[7])[1:]
                cls1['end'] = text_wrap('-', '周', lesson[7])
                cls1['isDan'] = 0
                if ('单' in lesson[7]):
                    cls1['isDan'] = 1
                elif ('双' in lesson[7]):
                    cls1['isDan'] = 2
                cls1['length'] = 2
                if (lesson[7][7] == '5'):
                    cls1['length'] = 3
                lesson.append(cls1)
                del lesson[:10]
            if (len(lesson) == 15):
                cls1['name'] = lesson[0]
                cls1['teacher'] = lesson[3]
                cls1['room'] = lesson[4]
                cls1['begin'] = text_wrap('{', '-', lesson[2])[1:]
                cls1['end'] = text_wrap('-', '周', lesson[2])
                cls1['isDan'] = 0
                if ('单' in lesson[2]):
                    cls1['isDan'] = 1
                elif ('双' in lesson[2]):
                    cls1['isDan'] = 2
                cls1['length'] = 2
                if (lesson[2][7] == '5'):
                    cls1['length'] = 3
                lesson.append(cls1)

                cls1 = {}
                cls1['name'] = lesson[5]
                cls1['teacher'] = lesson[8]
                cls1['room'] = lesson[9]
                cls1['begin'] = text_wrap('{', '-', lesson[7])[1:]
                cls1['end'] = text_wrap('-', '周', lesson[7])
                cls1['isDan'] = 0
                if ('单' in lesson[7]):
                    cls1['isDan'] = 1
                elif ('双' in lesson[7]):
                    cls1['isDan'] = 2
                cls1['length'] = 2
                if (lesson[7][7] == '5'):
                    cls1['length'] = 3
                lesson.append(cls1)

                cls1 = {}
                cls1['name'] = lesson[10]
                cls1['teacher'] = lesson[13]
                cls1['room'] = lesson[14]
                cls1['begin'] = text_wrap('{', '-', lesson[12])[1:]
                cls1['end'] = text_wrap('-', '周', lesson[12])
                cls1['isDan'] = 0
                if ('单' in lesson[12]):
                    cls1['isDan'] = 1
                elif ('双' in lesson[12]):
                    cls1['isDan'] = 2
                cls1['length'] = 2
                if (lesson[12][7] == '5'):
                    cls1['length'] = 3
                lesson.append(cls1)
                del lesson[:15]

            if (len(lesson) == 20):
                cls1['name'] = lesson[0]
                cls1['teacher'] = lesson[3]
                cls1['room'] = lesson[4]
                cls1['begin'] = text_wrap('{', '-', lesson[2])[1:]
                cls1['end'] = text_wrap('-', '周', lesson[2])
                cls1['isDan'] = 0
                if ('单' in lesson[2]):
                    cls1['isDan'] = 1
                elif ('双' in lesson[2]):
                    cls1['isDan'] = 2
                cls1['length'] = 2
                if (lesson[2][7] == '5'):
                    cls1['length'] = 3
                lesson.append(cls1)

                cls1 = {}
                cls1['name'] = lesson[5]
                cls1['teacher'] = lesson[8]
                cls1['room'] = lesson[9]
                cls1['begin'] = text_wrap('{', '-', lesson[7])[1:]
                cls1['end'] = text_wrap('-', '周', lesson[7])
                cls1['isDan'] = 0
                if ('单' in lesson[7]):
                    cls1['isDan'] = 1
                elif ('双' in lesson[7]):
                    cls1['isDan'] = 2
                cls1['length'] = 2
                if (lesson[7][7] == '5'):
                    cls1['length'] = 3
                lesson.append(cls1)

                cls1 = {}
                cls1['name'] = lesson[10]
                cls1['teacher'] = lesson[13]
                cls1['room'] = lesson[14]
                cls1['begin'] = text_wrap('{', '-', lesson[12])[1:]
                cls1['end'] = text_wrap('-', '周', lesson[12])
                cls1['isDan'] = 0
                if ('单' in lesson[12]):
                    cls1['isDan'] = 1
                elif ('双' in lesson[12]):
                    cls1['isDan'] = 2
                cls1['length'] = 2
                if (lesson[12][7] == '5'):
                    cls1['length'] = 3
                lesson.append(cls1)

                cls1 = {}
                cls1['name'] = lesson[15]
                cls1['teacher'] = lesson[18]
                cls1['room'] = lesson[19]
                cls1['begin'] = text_wrap('{', '-', lesson[17])[1:]
                cls1['end'] = text_wrap('-', '周', lesson[17])
                cls1['isDan'] = 0
                if ('单' in lesson[17]):
                    cls1['isDan'] = 1
                elif ('双' in lesson[17]):
                    cls1['isDan'] = 2
                cls1['length'] = 2
                if (lesson[17][7] == '5'):
                    cls1['length'] = 3
                lesson.append(cls1)

                del lesson[:20]

            if (len(lesson) == 7):
                cls1['name'] = lesson[0]
                cls1['teacher'] = lesson[3]
                cls1['room'] = lesson[4]
                cls1['begin'] = text_wrap('{', '-', lesson[2])[1:]
                cls1['end'] = text_wrap('-', '周', lesson[2])
                cls1['isDan'] = 0
                if ('单' in lesson[2]):
                    cls1['isDan'] = 1
                elif ('双' in lesson[2]):
                    cls1['isDan'] = 2
                cls1['length'] = 2
                if (lesson[2][7] == '5'):
                    cls1['length'] = 3

                lesson.clear()
                lesson.append(cls1)
            if (len(lesson) == 14):
                cls1 = {}
                cls1['name'] = lesson[0]
                cls1['teacher'] = lesson[3]
                cls1['room'] = lesson[4]
                cls1['begin'] = text_wrap('{', '-', lesson[2])[1:]
                cls1['end'] = text_wrap('-', '周', lesson[2])
                cls1['isDan'] = 0
                if ('单' in lesson[2]):
                    cls1['isDan'] = 1
                elif ('双' in lesson[2]):
                    cls1['isDan'] = 2
                cls1['length'] = 2
                if (lesson[2][7] == '5'):
                    cls1['length'] = 3
                lesson.append(cls1)

                cls1 = {}
                cls1['name'] = lesson[7]
                cls1['teacher'] = lesson[10]
                cls1['room'] = lesson[11]
                cls1['begin'] = text_wrap('{', '-', lesson[9])[1:]
                cls1['end'] = text_wrap('-', '周', lesson[9])
                cls1['isDan'] = 0
                if ('单' in lesson[9]):
                    cls1['isDan'] = 1
                elif ('双' in lesson[9]):
                    cls1['isDan'] = 2
                cls1['length'] = 2
                if (lesson[9][7] == '5'):
                    cls1['length'] = 3
                lesson.append(cls1)
                del lesson[:14]

    print(name, major)
    print(Class_list)
    data = {}
    # data = ""
    # data = data + State_Code
    # data = data + grade

    # data.append(State_Code)
    # data.append(grade)
    # data.append(name)
    # data.append(Class_list)
    # data.append(name)
    # data.append(major)

    data['grade'] = grade
    data['credit'] = 1
    data['GPA'] = GPA[-4:]
    data['user_token'] = user
    data['timetable'] = Class_list
    data['name'] = name
    data['major'] = major
    data['State_Code'] = State_Code
    data['Exam'] = Examlist
    return data

    #return json.dumps(data)



#User_login('2017011398', 'mcy200091')